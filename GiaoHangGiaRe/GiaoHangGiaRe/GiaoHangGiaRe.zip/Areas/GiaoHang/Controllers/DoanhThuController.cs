﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GiaoHangGiaRe.Areas.GiaoHang.Controllers
{
    public class DoanhThuController : Controller
    {
        // GET: GiaoHang/DoanhThu
        public ActionResult Index()
        {
            return View();
        }
    }
}